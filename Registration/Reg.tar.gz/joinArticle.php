<?php
/*
* FILE:joinArticle.php
* DATE:2009/05/26
* AUTHOR:tgbsa
* 加入會員條款
*/

require_once("../config.php");

    session_start();
    if(array_key_exists('agree', $_GET)){
       $_SESSION['agree'] = true;	
       header('Location: registerchoose.html');
    }
    else{
      $tpl = new Smarty();
      $tpl->display('joinArticle.tpl');
    }

?>
