<?php
/***
FILE:   register_success.php
DATE:   2006/11/26
AUTHOR: zqq
MODIFIER:tgbsa
填寫個人基本資料的頁面
**/
require_once("../config.php");
require_once('../library/mail.php');

	//開啟session
	session_start();
	if(!isset($_SESSION['register']['login_id'])){
	  echo "請依正確流程瀏覽網頁";
	  exit;
	}


	//去除重複的斜線
	$WEBROOT = substr($WEBROOT,1,strlen($WEBROOT));
	//set sender
	$from= 'elearning@mail.moe.gov.tw';
	//set message title and content
	$fromName= '教育部數位學習服務平台';
	$subject = "帳號開通確認";
	$message = "
	   {$_SESSION['values']['txtName']}同學您好
	  
	   您已經在教育部數位學習服務平台註冊了新的帳號，帳號為{$_SESSION['register']['login_id']}

	   如您沒在此平台註冊帳號，您不必理會本信的內容。

	   開通帳號請點選以下的連結以來正式啟用帳號。

	   URL:<a href={$HOMEURL}{$WEBROOT}Registration/validateUser.php?id={$_SESSION['personal_id']}&r={$_SESSION['randvalue']}>{$HOMEURL}{$WEBROOT}Registration/validateUser.php?id={$_SESSION['personal_id']}&r={$_SESSION['randvalue']}</a>
	   
	   這是系統自動發出的信件，請勿回覆。";

	$message = nl2br($message);
	
	$mailresult = mailto($from , $fromName, $_SESSION['values']['txtEmail'], $subject, $message);

/*	
	if($mailresult)
	  echo "mail success.\n";
	else
          echo "mail failed.\n";
 */	
	//new smarty	

	$tpl = new Smarty();
	//------註冊狀態的圖---------
	$IMAGE_PATH = "../" . $IMAGE_PATH;
	$tpl->assign("registerState", $IMAGE_PATH . "register_3.PNG");
	
	//輸出頁面
	$tpl->display("register_success.tpl");

?>
