<?php /* Smarty version 2.6.14, created on 2010-05-21 16:47:15
         compiled from forgetpasswd.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'escape', 'forgetpasswd.tpl', 31, false),)), $this); ?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="/themes/IE2/css/font_style.css" rel="stylesheet" type="text/css" />
<link href="css/register.css" rel="stylesheet" type="text/css" />
<title>忘記密碼</title>	
</head>
<body>
<table width="60%" border="0" align="center" cellpadding="0" cellspacing="0">
<!-- fwtable fwsrc="￥?cR|W" fwbase="001.jpg" fwstyle="Dreamweaver" fwdocid = "2142844055" fwnested="0" -->
  <tr>
   <td width="23"><img src="../images/registration/spacer.gif" width="23" height="1" border="0" alt=""></td>
   <td width="899"><img src="../images/registration/spacer.gif" width="607" height="1" border="0" alt=""></td>
   <td width="10"><img src="../images/registration/spacer.gif" width="7" height="1" border="0" alt=""></td>
   <td width="22"><img src="../images/registration/spacer.gif" width="22" height="1" border="0" alt=""></td>
   <td width="4"><img src="../images/registration/spacer.gif" width="4" height="1" border="0" alt=""></td>
  </tr>
  <tr>
   <td width="23" background="images/registration/001_r2_c4.jpg"><img name="n001_r2_c2" src="../images/registration/001_r2_c2.jpg" width="23" height="36" border="0" alt=""></td>
   <td colspan="2" background="../images/registration/001_r2_c4.jpg"><img name="n001_r2_c3" src="../images/registration/005_r2_c3.jpg" width="607" height="36" border="0" alt=""></td>
   <td><img name="n001_r2_c5" src="../images/registration/001_r2_c5.jpg" width="22" height="36" border="0" alt=""></td>
   <td><img name="n001_r2_c6" src="../images/registration/001_r2_c6.jpg" width="4" height="36" border="0" alt=""></td>
  </tr>
  <tr>
   <td width="23" background="../images/registration/001_r3_c2.jpg">&nbsp;</td>
   <td colspan="2"><p>&nbsp;</p>
   <table class="datatable" width="550" border=0 align="center">
<form action="<?php echo $this->_tpl_vars['thisaction']; ?>
" method="POST" target="_self">
<tr>
    <td width="200">請輸入帳號</td>
    <td ><input type="text" name="id" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['id'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
" <?php echo $this->_tpl_vars['id_readonly']; ?>
 /><br/><div style="font-size:12px"><?php echo ((is_array($_tmp=$this->_tpl_vars['id_errmsg'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</div></td>
</tr>

<?php if (isset ( $this->_tpl_vars['hint'] )): ?>

<tr>
    <td width="200">密碼提示</td>
    <td ><?php echo $this->_tpl_vars['hint']; ?>
</td>
</tr>
<?php endif; ?>
<tr>
    <td>請輸入註冊所填的E-mail<div style="font-size:12px">(若忘記E-MAIL時 請與網站管理者聯繫)</div></td>
    <td><input type="text" name="email" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['email'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
"/><br/><div style="font-size:12px"><?php echo ((is_array($_tmp=$this->_tpl_vars['email_errmsg'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</div></td>
</tr>
<?php if (isset ( $this->_tpl_vars['confirm'] )): ?>
<tr>
    <td colspan="2">
	<div style="font-size:12px; text-align:center">
		<?php echo ((is_array($_tmp=$this->_tpl_vars['prompt'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
按下【送出】將會寄出新密碼至您的信箱。
	</div>
	</td>
</tr>
<?php endif; ?>

<tr>
    <td colspan="2">
	<div style="text-align:center">
	<input type="submit" value="送出"/>&nbsp;&nbsp;&nbsp;
	<input type="button" value="重設" onclick="window.location.href='forgetpasswd.php'"/>

	</div>
	</td>
</tr>
<input type="hidden" name="code_state" value="<?php echo $this->_tpl_vars['code_state']; ?>
"/>
</form>
</table>
   <p>&nbsp;</p></td>
   <td colspan="2" background="../images/registration/001_r3_c5.jpg"><img name="n001_r3_c6" src="../images/registration/001_r3_c6.jpg" width="4" height="7" border="0" alt=""></td>
  </tr>
  <tr>
   <td width="23"><img name="n001_r5_c2" src="../images/registration/001_r5_c2.jpg" width="23" height="21" border="0" alt=""></td>
   <td colspan="2" background="../images/registration/001_r5_c4.jpg"><img name="n001_r5_c4" src="../images/registration/001_r5_c4.jpg" width="7" height="21" border="0" alt=""></td>
   <td><img name="n001_r5_c5" src="../images/registration/001_r5_c5.jpg" width="22" height="21" border="0" alt=""></td>
   <td><img name="n001_r5_c6" src="../images/registration/001_r5_c6.jpg" width="4" height="21" border="0" alt=""></td>
  </tr>
</table>
</body>


</html>