<?php /* Smarty version 2.6.14, created on 2010-05-19 14:01:34
         compiled from register_success.tpl */ ?>
<html>
<head> 
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link href="/themes/IE2/css/font_style.css" rel="stylesheet" type="text/css" />
	<title>註冊成功</title>
</head>

<body>
<body bgcolor="#ffffff">
<p align="center"><img src="../images/registration/step3.jpg" width="475" height="119"></p>
<table width="60%" border="0" align="center" cellpadding="0" cellspacing="0">
<!-- fwtable fwsrc="￥?cR|W" fwbase="001.jpg" fwstyle="Dreamweaver" fwdocid = "2142844055" fwnested="0" -->
  <tr>
   <td width="23"><img src="../images/registration/spacer.gif" width="23" height="1" border="0" alt=""></td>
   <td width="899"><img src="../images/registration/spacer.gif" width="607" height="1" border="0" alt=""></td>
   <td width="10"><img src="../images/registration/spacer.gif" width="7" height="1" border="0" alt=""></td>
   <td width="22"><img src="../images/registration/spacer.gif" width="22" height="1" border="0" alt=""></td>
   <td width="4"><img src="../images/registration/spacer.gif" width="4" height="1" border="0" alt=""></td>
  </tr>
  <tr>
   <td width="23" background="images/registration/001_r2_c4.jpg"><img name="n001_r2_c2" src="../images/registration/001_r2_c2.jpg" width="23" height="36" border="0" alt=""></td>
   <td colspan="2" background="../images/registration/001_r2_c4.jpg"><img name="n001_r2_c3" src="../images/registration/004_r2_c3.jpg" width="607" height="36" border="0" alt=""></td>
   <td><img name="n001_r2_c5" src="../images/registration/001_r2_c5.jpg" width="22" height="36" border="0" alt=""></td>
   <td><img name="n001_r2_c6" src="../images/registration/001_r2_c6.jpg" width="4" height="36" border="0" alt=""></td>
  </tr>
  <tr>
   <td width="23" background="../images/registration/001_r3_c2.jpg">&nbsp;</td>
   <td colspan="2"><center>
     <p><img src="../images/registration/004_r5_c4.jpg" width="472" height="129"></p>
     <p align="center"></p><input type="button" value="返回首頁" onClick="location.href='../index.php';" /></p>
     <p align="center">&nbsp;</p>
     <p align="center">&nbsp;</p>
   </center></td>
   <td colspan="2" background="../images/registration/001_r3_c5.jpg"><img name="n001_r3_c6" src="../images/registration/001_r3_c6.jpg" width="4" height="7" border="0" alt=""></td>
  </tr>
  <tr>
   <td width="23"><img name="n001_r5_c2" src="../images/registration/001_r5_c2.jpg" width="23" height="21" border="0" alt=""></td>
   <td colspan="2" background="../images/registration/001_r5_c4.jpg"><img name="n001_r5_c4" src="../images/registration/001_r5_c4.jpg" width="7" height="21" border="0" alt=""></td>
   <td><img name="n001_r5_c5" src="../images/registration/001_r5_c5.jpg" width="22" height="21" border="0" alt=""></td>
   <td><img name="n001_r5_c6" src="../images/registration/001_r5_c6.jpg" width="4" height="21" border="0" alt=""></td>
  </tr>
</table>
</body>
</html>