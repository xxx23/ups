<?php
//下面這行就可以使用 cyberccu2 原本的 session
//require('/home/zoe/WWW/session.php');
require('../../../../session.php');
$begin_course_cd_before = $_SESSION['begin_course_cd'];
$personal_id_before = $_SESSION['personal_id'];
//print '<pre>';
//print_r($_SESSION);

//下面這行就會改採用 moodle 的 session
require_once("../../config.php");
require_once('locallib.php');

$_SESSION['begin_course_cd']= $begin_course_cd_before ; 
$_SESSION['personal_id']= $personal_id_before ;
$begin_course_cd=$_SESSION['begin_course_cd'];
$personal_id=$_SESSION['personal_id'];
//從begin_course_cd查content_cd
$sql = "select content_cd  from class_content_current where begin_course_cd = $begin_course_cd";
$content_cd = db_getOne($sql);
//從content_cd查scorm_id
$sql = "select id  from mdl_scorm  where content_cd ='$content_cd'";
$scorm_id= db_getOne($sql);

?>
<html>
<head>
<script type="text/javascript">
function openWin()
  {
	  myWindow=window.open("","","fullscreen=3,resizable=yes,scrollbars=yes,left=1000,top=0");
      myWindow.location.href('./view.php?a=<?php echo $scorm_id?>');
  }
</script>
</head>
<body>

<input type="button" value="Open 'ScormWindow'" onclick="openWin()" />
<br /><br />
</body>
</html>
