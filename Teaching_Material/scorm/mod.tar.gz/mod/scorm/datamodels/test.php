<?php
  echo $datastring;
?>
